from enum import Enum

class FloorLevel(Enum):
    LOWER = 1
    UPPER = 2
