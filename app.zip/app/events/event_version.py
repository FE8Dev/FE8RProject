from enum import Enum

class EventVersion(Enum):
    EVENT = 0
    PYEV1 = 1
