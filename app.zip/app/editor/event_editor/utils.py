
from enum import Enum

class EditorLanguageMode(Enum):
    UNSET = -1
    PYTHON = 0
    EVENT = 1
