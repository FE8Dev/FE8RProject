from enum import Enum


class MainEditorScreenStates(Enum):
    GLOBAL_EDITOR = 0
    LEVEL_EDITOR = 1
    OVERWORLD_EDITOR = 2
