WARNING_MSG = """
###############################################################################################################################
# This code was generated using `source_generator.py`. DO NOT MAKE ANY EDITS TO THIS FILE - YOUR CHANGES WILL BE OVERWRITTEN. #
###############################################################################################################################
"""

def get_codegen_header() -> str:
    return WARNING_MSG
