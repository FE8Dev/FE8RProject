from app.constants import WINWIDTH, WINHEIGHT

from app.data.database.database import DB
from app.data.resources.resources import RESOURCES
from app.utilities import utils

from app.engine.fonts import FONT
from app.engine.sprites import SPRITES
from app.engine.sound import get_sound_thread
from app.engine.state import State
from app.engine import (background, combat_calcs, engine, equations, gui,
                        help_menu, icons, image_mods, item_funcs, item_system,
                        skill_system, text_funcs, unit_funcs, menus, action, dialog, battle_animation)
from app.engine.combat.mock_combat import MockCombat
from app.engine.game_state import game
from app.engine.fluid_scroll import FluidScroll
from app.engine.objects.skill import SkillObject
from app.engine.info_menu.info_graph import InfoGraph, info_states
from app.engine.info_menu.info_menu_portrait import InfoMenuPortrait

from app.engine.promotion_info_graph import InfoGraph
from app.engine.input_manager import get_input_manager

import logging
import pygame


class PromotionChoiceState(State):
    name = 'promotion_choice'
    bg = None

    def __init__(self, name=None):
        self.name = name
        self.bg = background.create_background('settings_background')

    def _get_choices(self):
        self.class_options = game.memory.get('promo_options', None) or self.unit_klass.turns_into
        game.memory['promo_options'] = None
        return [DB.classes.get(c).name for c in self.class_options]

    def _proceed(self, next_class):
        game.memory['current_unit'] = self.unit
        game.memory['next_class'] = next_class
        game.memory['next_state'] = 'promotion'
        game.state.change('transition_to_with_pop')

    def start(self):
        self.fluid = FluidScroll()

        self.can_go_back = game.memory.get('can_go_back', False)
        game.memory['can_go_back'] = None
        self.combat_item = game.memory.get('combat_item')
        game.memory['combat_item'] = None
        self.unit = game.memory['current_unit']
        self.unit_klass = DB.classes.get(self.unit.klass)
        display_options = self._get_choices()

        self.menu = menus.Choice(self.unit, display_options, (14, 13))
        self.menu.set_limit(3)
        self.child_menu = None
        self.skills = []

        self.info_graph = InfoGraph()
        self.info_graph.set_options(self.class_options)
        if 'personal_data' not in self.info_graph.registry:
            self.info_graph.registry['personal_data'] = []
        self.info_graph.clear()
        self.info_flag = False
		
        for idx, option in enumerate(self.class_options):
            klass = DB.classes.get(option)
            text = text_funcs.translate_and_text_evaluate(klass.desc, self=klass, unit=self.unit)

    # Register help box at menu item positions
            self.info_graph.register(
           (14, 13 + 16 * idx, 160, 16),  # Position and size of help box
           help_menu.HelpDialog(text, name=klass.name),  # Help text
           option)  # State (each option gets its own help box))
        
        self.animations = []
        self.weapon_icons = []
        for option in self.class_options:
            anim = battle_animation.get_battle_anim(self.unit, None, klass=option)
            if anim:
                anim.pair(self, None, True, 0)
            self.animations.append(anim)
            weapons = []
            klass = DB.classes.get(option)
            for weapon_nid, weapon in klass.wexp_gain.items():
                if weapon.usable:
                    weapons.append(weapon_nid)
            self.weapon_icons.append(weapons)
            # Skills
            class_skills = []
            for skill_level, skill_nid in klass.learned_skills:
                if skill_nid not in self.unit.skills:
                    if "_hide" not in skill_nid:
                        class_skills.append(skill_nid)
                        skill = SkillObject.from_prefab(DB.skills.get(skill_nid))
                        self.info_graph.register((180 + 16 * class_skills.index(skill_nid), 6, 16, 16), help_menu.HelpDialog(skill.desc, name=skill.name), option)
            self.skills.append(class_skills)

        # Platforms
        if game.tilemap and self.unit.position:
            terrain = game.tilemap.get_terrain(self.unit.position)
            platform_type = DB.terrain.get(terrain).platform
        else:
            platform_type = 'Floor'
        platform = RESOURCES.platforms[platform_type + '-Melee']
        self.left_platform = engine.image_load(platform)
        self.right_platform = engine.flip_horiz(self.left_platform.copy())

        # For anim swoop in
        self.anim_offset = 120
        self.target_anim_offset = False

        self.current_desc = self._get_desc()

        game.state.change('transition_in')
        return 'repeat'

    def begin(self):
        self.fluid.reset_on_change_state()

    def take_input(self, event):
        first_push = self.fluid.update()
        directions = self.fluid.get_directions()

        # Handle mouse movement
        current_idx = self.menu.get_current_index()
        self.menu.handle_mouse()
        new_idx = self.menu.get_current_index()
        if current_idx != new_idx:  # Mouse moved
            get_sound_thread().play_sfx('Select 6')
            self.target_anim_offset = True
            self.current_desc = self._get_desc()
            # Update info graph if in info mode
            if self.info_flag:
                self.info_graph.set_current_state(self.class_options[self.menu.get_current_index()])
                self.info_graph.set_transition_in()

        # Handle special info mode
        if self.info_flag:
            if event == 'INFO':
                get_sound_thread().play_sfx('Info In')
                self.menu.draw_cursor = False  # Use False instead of 0
                self.menu.takes_input = True
                
                if not self.info_graph.current_state:
                    self.info_graph.set_current_state(self.class_options[self.menu.get_current_index()])
                
                self.info_graph.set_transition_in()
            elif 'DOWN' in directions:
                get_sound_thread().play_sfx('Select 6')
                if self.child_menu:
                    self.child_menu.move_down(first_push)
                else:
                    self.menu.move_down(first_push)
                    self.target_anim_offset = True
                    self.current_desc = self._get_desc()
                    # Update help box
                    self.info_graph.set_current_state(self.class_options[self.menu.get_current_index()])
                    self.info_graph.set_transition_in()
            elif 'UP' in directions:
                get_sound_thread().play_sfx('Select 6')
                if self.child_menu:
                    self.child_menu.move_up(first_push)
                else:
                    self.menu.move_up(first_push)
                    self.target_anim_offset = True
                    self.current_desc = self._get_desc()
                    # Update help box
                    self.info_graph.set_current_state(self.class_options[self.menu.get_current_index()])
                    self.info_graph.set_transition_in()
            elif 'RIGHT' in directions:
                get_sound_thread().play_sfx('Select 6')
                self.info_graph.move_right()
            elif 'LEFT' in directions:
                get_sound_thread().play_sfx('Select 6')
                self.info_graph.move_left()
            elif event == 'BACK':
                get_sound_thread().play_sfx('Info Out')
                self.info_graph.set_transition_out()
                self.info_flag = False
                self.menu.draw_cursor = True  # Use True instead of 1
                self.menu.draw_cursor = 1
                self.menu.takes_input = True
        else:
            # Normal menu navigation (not in info mode)
            if 'DOWN' in directions:
                get_sound_thread().play_sfx('Select 6')
                if self.child_menu:
                    self.child_menu.move_down(first_push)
                else:
                    self.menu.move_down(first_push)
                    self.target_anim_offset = True
                    self.current_desc = self._get_desc()
            elif 'UP' in directions:
                get_sound_thread().play_sfx('Select 6')
                if self.child_menu:
                    self.child_menu.move_up(first_push)
                else:
                    self.menu.move_up(first_push)
                    self.target_anim_offset = True
                    self.current_desc = self._get_desc()

            elif event == 'SELECT':
                if self.child_menu:
                    selection = self.child_menu.get_current()
                    if selection == 'Change':
                        get_sound_thread().play_sfx('Select 1')
                        self._proceed(self.class_options[self.menu.get_current_index()])
                    else:
                        get_sound_thread().play_sfx('Select 4')
                        self.child_menu = None
                else:
                    get_sound_thread().play_sfx('Select 1')
                    selection = self.menu.get_current()
                    self.menu.draw_cursor = 0
                    self.menu.takes_input = False
                    options = ['Change', 'Cancel']
                    self.child_menu = menus.Choice(selection, options, self.menu)

            elif event == 'BACK':
                if self.child_menu:
                    get_sound_thread().play_sfx('Select 4')
                    self.child_menu = None
                    self.menu.draw_cursor = 1
                    self.menu.takes_input = True
                elif self.can_go_back:
                    get_sound_thread().play_sfx('Select 4')
                    game.state.back()
                    if self.combat_item:
                        action.do(action.HasNotAttacked(self.unit))
                        item_system.reverse_use(self.unit, self.combat_item)
                else:
                    # Can't go back...
                    get_sound_thread().play_sfx('Error')


            elif event == 'INFO':
                # Enter info mode
                get_sound_thread().play_sfx('Info In')
                
                # Set the info graph to the current menu item's description
                current_index = self.menu.get_current_index()
                self.info_graph.set_current_state(self.class_options[current_index])
                
                self.info_flag = True
                self.menu.draw_cursor = False
                self.info_graph.set_transition_in()

    def handle_back_button(self):
        """Handles BACK button behavior and ensures correct cursor positioning."""
        if self.info_flag:  
            # If in INFO mode, exit INFO 
            get_sound_thread().play_sfx('Info Out')
            self.info_flag = False
            self.menu.draw_cursor = True
        else:
            # If not in INFO mode, return to the previous menu 
            # Ensure cursor stays within the menu's option range
            self.menu.cursor_pos = self.menu.get_current_index()
            self.game.state.back()
            if hasattr(self.menu, 'options'):
                self.menu.cursor_pos = min(
                    max(0, self.menu.cursor_pos), 
                    len(self.menu.options) - 1
                ) 

    def enter_info_mode(self):
        """Enters INFO mode and saves current cursor position."""
        self.last_cursor_pos = self.menu.cursor_pos  # Save position before switching
        self.info_flag = True

    def move_cursor(self, direction):
        """Handles cursor movement while ensuring it stays within valid range."""
        new_pos = self.menu.cursor_pos + direction
        if 0 <= new_pos < len(self.menu.options):
            self.menu.cursor_pos = new_pos
			
    def _get_growth_changes(self):
        current_klass = self.class_options[self.menu.get_current_index()]
        
        base_growths = DB.units.get(self.unit.nid).growths
        new_klass_growths = DB.classes.get(current_klass).growths
        new_klass_growth_bonus = DB.classes.get(current_klass).growth_bonus
        
        growth_changes = {nid: 0 for nid in DB.stats.keys()}

        for stat_nid in growth_changes.keys():
            base = base_growths.get(stat_nid, 0)
            change = new_klass_growths.get(stat_nid, 0)
            bonus_change = new_klass_growth_bonus.get(stat_nid, 0)
            
            growth_changes[stat_nid] = base + bonus_change
            
        return growth_changes

    def _get_stat_changes(self):
        current_klass = self.class_options[self.menu.get_current_index()]
        
        promotion_gains = DB.classes.get(current_klass).promotion
        
        current_stats = self.unit.stats
        new_klass_maxes = DB.classes.get(current_klass).max_stats
        new_klass_bases = DB.classes.get(current_klass).bases
        old_klass_bases = DB.classes.get(self.unit.klass).bases
        
        stat_changes = {nid: 0 for nid in DB.stats.keys()}
        for stat_nid in DB.stats.keys():
            stat_value = promotion_gains.get(stat_nid, 0)
            if stat_value == -99:  # Just use the new klass base
                stat_changes[stat_nid] = new_klass_bases.get(stat_nid, 0) - current_stats[stat_nid]
            elif stat_value == -98:  # Use the new klass base only if it's bigger
                stat_changes[stat_nid] = max(0, new_klass_bases.get(stat_nid, 0) - current_stats[stat_nid])
            elif stat_value == -97: # Subtract the old klass base from the new klass base
                change = new_klass_bases.get(stat_nid, 0) - old_klass_bases.get(stat_nid, 0)
                current_stat = current_stats.get(stat_nid)
                new_value = utils.clamp(change, -current_stat, new_klass_maxes.get(stat_nid, 0) + self.unit.stat_cap_modifiers.get(stat_nid, 0) - current_stat)
                stat_changes[stat_nid] = new_value
            else:
                max_gain_possible = new_klass_maxes.get(stat_nid, 0) + self.unit.stat_cap_modifiers.get(stat_nid, 0) - current_stats[stat_nid]
                stat_changes[stat_nid] = min(stat_value, max_gain_possible)
        return stat_changes
		
    def get_promo_changes(self):
        stat_changes = self._get_stat_changes()
        growth_changes = self._get_growth_changes()

        combined_changes = [
            (nid, stat_changes.get(nid, 0), growth_changes.get(nid, 0)) 
            for nid in DB.stats.keys()
        ]
        return combined_changes

    def growth_colors(self, value):
        color = 'yellow'
        if value < 0: # Negative growths
            color = 'purple'
        elif value == 0: # Zero growths
            color = 'grey'
        elif value > 0 and value <= 20:
            color = 'red-orange'
        elif value > 20 and value <= 30:
            color = 'light-red'
        elif value > 30 and value <= 40:
            color = 'pink-orange'
        elif value > 40 and value <= 50:
            color = 'light-orange'
        elif value > 50 and value <= 60:
            color = 'corn-yellow'
        elif value > 60 and value <= 70:
            color = 'light-green'
        elif value > 70 and value <= 80:
            color = 'olive-green'
        elif value > 80 and value <= 90:
            color = 'soft-green'
        else:  # > 90
            color = 'yellow-green'
        return color


    def draw(self, surf):
        if not self.started:
            return surf
        
        self.bg.draw(surf)
        
        top = WINHEIGHT - 99
        surf.blit(self.left_platform, (WINWIDTH//2 - self.left_platform.get_width() + self.anim_offset + 52, top))
        surf.blit(self.right_platform, (WINWIDTH//2 + self.anim_offset + 52, top))
        anim = self.animations[self.menu.get_current_index()]
        if anim:
            anim.draw(surf, (self.anim_offset + 12, -27))

    def _get_desc(self):
        current_klass = self.class_options[self.menu.get_current_index()]
        klass = DB.classes.get(current_klass)
        text = text_funcs.translate_and_text_evaluate(klass.desc, self=klass)
        d = dialog.Dialog(text.replace('\n', '{br}'))
        d.position = (6, 112)
        d.text_width = WINWIDTH - 28
        d.width = d.text_width + 16
        d.font_type = 'convo'
        d.font_color = 'white'
        d.font = FONT['convo-white']
        d.draw_cursor_flag = False
        d.reformat()
        return d

    def update(self):
        self.menu.update()
        if self.child_menu:
            self.child_menu.update()
        if self.current_desc:
            self.current_desc.update()

        if self.target_anim_offset:
            self.anim_offset += 8
            if self.anim_offset >= 120:
                self.target_anim_offset = False
                self.anim_offset = 120
        elif self.anim_offset > 0:
            self.anim_offset -= 8
            if self.anim_offset < 0:
                self.anim_offset = 0

        anim = self.animations[self.menu.get_current_index()]
        if anim:
            anim.update()

    def draw(self, surf):
        if not self.started:
            return surf

        self.bg.draw(surf)

        top = WINHEIGHT - 99
        surf.blit(self.left_platform, (WINWIDTH//2 - self.left_platform.get_width() + self.anim_offset + 52, top))
        surf.blit(self.right_platform, (WINWIDTH//2 + self.anim_offset + 52, top))
        anim = self.animations[self.menu.get_current_index()]
        if anim:
            anim.draw(surf, (self.anim_offset + 12, -27))

        # Class Reel
        #FONT['class'].blit(self.menu.get_current(), surf, (5, 4))

        # Weapon Icons
        for idx, weapon in enumerate(self.weapon_icons[self.menu.get_current_index()]):
            icons.draw_weapon(surf, weapon, (114 + 16 * idx, 5))

        # Skill Icons
        for idx, skill_nid in enumerate(self.skills[self.menu.get_current_index()]):
            skill = SkillObject.from_prefab(DB.skills.get(skill_nid))
            #icons.draw_skill(surf, skill, (130 + 16 * idx, 50), simple=True)
            icons.draw_skill(surf, skill, (180 + 16 * idx, 5), simple=True)
            #self.info_graph.register((180 + 16 * idx, 32, 16, 16), help_menu.HelpDialog(skill.desc, skill.name), ('Option' + str(self.menu.get_current_index())))
            #logging.warning("Skill registered: %s %s", skill.nid, ('Option' + str(self.menu.get_current_index())))

        if self.menu:
            self.menu.draw(surf)
        if self.child_menu:
            self.child_menu.draw(surf)

        # Promo bonuses
        original_sprite = SPRITES.get('promotion_description')
        scaled_sprite = pygame.transform.scale(original_sprite, (240,72))# Adjust size
        surf.blit(scaled_sprite, (0, 96))
     

        left, top = 8, 104
        font = FONT['text_numbers']
        gap = font.width('999') + 2
        inset = 4
        idx = 0
        promo_bonuses = self.get_promo_changes()
        
        header_font = FONT['small']
        
        if 'personal_data' not in self.info_graph.registry:
            self.info_graph.registry['personal_data'] = []  # Ensure 'personal_data' exists before registering
		
        header = 'STAT CHANGES'
        header_font.blit(header, surf, (left + 2, top - 11))
        self.info_graph.register((left + 2, top - 11 + 8, 16, 16),
                                 help_box=help_menu.HelpDialog(desc='How the unit\'s stats would change after reclassing. <green>Green</> means an increase, <red>red</> a decrease.'),
                                 state='personal_data',
                                 first=False
                                 )
        
        header = 'NEW GROWTHS'
        header_font.blit(header, surf, (left + 2, top + 20 - 12 + 2))
        self.info_graph.register((left + 2, top + 20 - 12 + 2+ 8, 16, 16),
                                 help_box=help_menu.HelpDialog(desc='The unit\'s new growths after reclassing. <green>Green</> means that the new growth is high. <red>Red</> means that it is low.'),
                                 state='personal_data',
                                 first=False
                                 )
        
        for nid, stat, growth in promo_bonuses:
            if nid != 'LEAD':
                # Stat changes
                color = 'light-red' if stat < 0 else 'olive-green'
                color = 'grey' if stat == 0 else color
                font.blit_right(str(stat).removeprefix('-'), surf, (left + inset + idx * gap + 12, top + 2), color=color)
                
                # New growths
                color = self.growth_colors(growth)
                color = 'grey' if nid in ('CON', 'MOV') else color
                font.blit_right(str(growth).removeprefix('-') if nid not in ('CON', 'MOV') else '--',
                                surf, (left + inset + idx * gap + 12, top + 20 + 2 + 2), color=color)
                # The stat names
                font.blit_center(nid.capitalize() if nid != 'LCK' else 'Luk', surf, (left + inset + 3 + idx * gap, top + 36))
                idx += 1
		
		
        #if self.current_desc:
            #self.current_desc.draw(surf)

        if self.info_graph.current_bb or self.info_flag:
            self.info_graph.draw(surf)
			
        return surf

        

class ClassChangeChoiceState(PromotionChoiceState):
    name = 'class_change_choice'

    def _get_choices(self):
        if game.memory.get('promo_options', None):
            self.class_options = game.memory['promo_options']
            game.memory['promo_options'] = None
        elif not self.unit.generic:
            unit_prefab = DB.units.get(self.unit.nid)
            self.class_options = [c for c in unit_prefab.alternate_classes if c != self.unit.klass]
        else:  # Just every class, lol?
            self.class_options = [c.nid for c in DB.classes.values() if c.nid != self.unit.klass]
        if DB.constants.value('class_change_same_tier'):
            self.class_options = [c for c in self.class_options if DB.classes.get(c).tier == DB.classes.get(self.unit.klass).tier]
        return [DB.classes.get(c).name for c in self.class_options]

    def _proceed(self, next_class):
        game.memory['current_unit'] = self.unit
        game.memory['next_class'] = next_class
        game.memory['next_state'] = 'class_change'
        game.state.change('transition_to_with_pop')

class PromotionState(State, MockCombat):
    name = 'promotion'
    bg = None

    def _finalize(self, current_time):
        self.state = 'level_up'
        self.last_update = current_time
        game.exp_instance.append((self.unit, 0, self, 'promote'))
        game.state.change('exp')

    def start(self):
        self.create_background()

        music = 'music_%s' % self.name
        self.promotion_song = None
        if game.game_vars.get('_' + music):
            self.promotion_song = \
                get_sound_thread().fade_in(game.game_vars.get('_' + music), fade_in=50)
        elif DB.constants.value(music):
            self.promotion_song = \
                get_sound_thread().fade_in(DB.constants.value(music), fade_in=50)

        self.unit = game.memory['current_unit']
        color = DB.teams.get(self.unit.team).combat_color

        # Old Right Animation
        self.right_battle_anim = battle_animation.get_battle_anim(self.unit, None)
        # New Left Animation
        next_class = game.memory['next_class']
        self.left_battle_anim = battle_animation.get_battle_anim(self.unit, None, klass=next_class)
        self.current_battle_anim = self.right_battle_anim

        platform_type = 'Floor'
        platform = RESOURCES.platforms[platform_type + '-Melee']
        self.left_platform = engine.image_load(platform)
        self.right_platform = engine.flip_horiz(self.left_platform.copy())

        # Name tag
        self.name_tag = SPRITES.get('combat_name_right_' + color).copy()
        width = FONT['text-brown'].width(self.unit.name)
        FONT['text-brown'].blit(self.unit.name, self.name_tag, (36 - width // 2, 8))

        # For darken backgrounds and drawing
        self.setup_dark()
        self.last_update = engine.get_time()
        self.state = 'init'

        if not self.right_battle_anim or not self.left_battle_anim:
            self._finalize(engine.get_time())
        else:
            game.state.change('transition_in')
            self.left_battle_anim.pair(self, self.right_battle_anim, False, 0)
            self.right_battle_anim.pair(self, self.left_battle_anim, True, 0)

        return 'repeat'

    def begin(self):
        self.last_update = engine.get_time()

    def start_anim(self, effect_nid):
        anim = self.current_battle_anim
        effect = anim.get_effect(effect_nid, pose='Attack')
        if effect:
            anim.add_effect(effect)

    def update(self):
        current_time = engine.get_time() - self.last_update
        self.current_state = self.state

        if self.state == 'init':
            if current_time > utils.frames2ms(25):
                self.state = 'right'
                self.start_anim('Promotion1')

        elif self.state == 'right':
            if not self.current_battle_anim.child_effects:
                self.current_battle_anim = self.left_battle_anim
                self.state = 'left'
                self.start_anim('Promotion2')

        elif self.state == 'left':
            if not self.current_battle_anim.child_effects:
                self.state = 'wait'

        elif self.state == 'wait':
            if current_time > utils.frames2ms(100):
                self._finalize(engine.get_time())

        elif self.state == 'level_up':
            self.state = 'leave'

        elif self.state == 'leave':
            if current_time > utils.frames2ms(10):
                game.state.change('transition_pop')
                self.state = 'done'
                if self.promotion_song:
                    get_sound_thread().fade_back()
                return 'repeat'

        if self.state != self.current_state:
            self.last_update = engine.get_time()

        # Update anims
        if self.current_battle_anim:
            self.current_battle_anim.update()

        if self.state == 'done':
            return 'repeat'

    def draw(self, surf):
        if self.bg:
            self.bg.draw(surf)
        else:
            return surf

        combat_surf = engine.copy_surface(self.combat_surf)

        # Platforms
        top = WINHEIGHT - 72
        combat_surf.blit(self.left_platform, (WINWIDTH//2 - self.left_platform.get_width(), top))
        combat_surf.blit(self.right_platform, (WINWIDTH//2, top))

        # Name Tag
        combat_surf.blit(self.name_tag, (WINWIDTH + 3 - self.name_tag.get_width(), 0))

        self.color_ui(combat_surf)

        surf.blit(combat_surf, (0, 0))

        if self.current_battle_anim:
            self.current_battle_anim.draw(surf)

        self.foreground.draw(surf)

        return surf

class ClassChangeState(PromotionState):
    name = 'class_change'

    def _finalize(self, current_time):
        self.state = 'level_up'
        self.last_update = current_time
        game.exp_instance.append((self.unit, 0, self, 'class_change'))
        game.state.change('exp')
