# to run all tests, use this command:
# python -m unittest app/engine/graphics/ui_framework/test/*.py